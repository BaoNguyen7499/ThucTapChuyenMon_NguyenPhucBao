﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Clothing_Store
{
    public class inhoadon
    {
        public int? id { get; set; }
        public DateTime? ngaydat { get; set; }
        public string hotenkhachang { get; set; }
        public string phuongthucthanhtoan { get; set; }
    }
}